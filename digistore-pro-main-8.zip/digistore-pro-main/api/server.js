import server from '../dist/server/server.js';
import { readFileSync, readdirSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const clientDir = join(__dirname, '../dist/client');

// Find the CSS file
const assetsDir = join(clientDir, 'assets');
const cssFile = readdirSync(assetsDir).find(f => f.endsWith('.css'));

export default async function handler(req, res) {
  try {
    const url = new URL(req.url, `https://${req.headers.host}`);

    const headers = new Headers();
    for (const [key, value] of Object.entries(req.headers)) {
      if (value) headers.set(key, Array.isArray(value) ? value.join(', ') : value);
    }

    const request = new Request(url.toString(), {
      method: req.method,
      headers,
      body: ['GET', 'HEAD'].includes(req.method) ? undefined : req,
    });

    const response = await server.fetch(request);
    
    res.statusCode = response.status;
    response.headers.forEach((value, key) => {
      res.setHeader(key, value);
    });

    let body = await response.text();

    // Inject CSS link if not present
    if (cssFile && body.includes('<head>') && !body.includes(cssFile)) {
      body = body.replace(
        '<head>',
        `<head><link rel="stylesheet" href="/assets/${cssFile}">`
      );
    }

    res.end(body);
  } catch (err) {
    console.error(err);
    res.statusCode = 500;
    res.end('Internal Server Error');
  }
}
